﻿SiSL's Mega Pack Customization
----------------------------------------------------
Version: 2.0

DISCLAIMER: YOU MAY NOT USE ITEMS IN OTHER MODS, SELL OR REUPLOAD. 
ONLY ALLOWED MODIFICATIONS ARE FOR PRIVATE USE ONLY AND ONLY IN CUSTOMIZATION FILE. 

OFFICIAL FACEBOOK PAGE: 
https://www.facebook.com/sislsmegapack/

Like and make sure to subscribe on Facebook page to see all 
items and upcoming features in next release.

DONATE: You can always send me a beer from
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=L8A48LEY9A9DG

This is customization pack for those who like to customize some of the mod's features

Please refer to our Facebook page:
https://radiotrucker.com/sislsmegapack/
